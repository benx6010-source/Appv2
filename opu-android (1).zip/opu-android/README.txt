ELIZABETH v3 (opu) - Android app

NEW IN v3
- App name ELIZABETH, version "v3 opu", black-white glow theme, bento grid home, everything animated.
- Opening animation: warp stars, glowing ring, star and letters.
- Chat (Claude-style): history sidebar, search, rename, delete, streaming replies, markdown + code copy,
  edit message, regenerate, read aloud, voice typing, image + text-file attach, export/share.
- Settings with Save / Reset for: Gemini key, model, persona, creativity, names, ElevenLabs key / voice id / agent id,
  app name, app icon, theme (System / Dark / Light), motion.
- 3D body: choose / replace / remove .glb or .vrm, size, position, turn, camera, light, sway, bounce, glow, animation, reset.
- Optional ElevenLabs voice (key + voice id). Empty = Android voice.
- Fixes: speech never resumed after tap-to-stop; crash if "Start" pressed before mic permission; wake word also works with
  the name you set and "Elizabeth".
- All old features kept (say "Opu", floating character, screen control, media, look at me, ask before risky actions).

BUILD THE APK FROM YOUR TABLET
1. Upload this zip to your GitHub repo with the SAME name (opu-android.zip). It replaces the old one.
2. Actions tab -> wait for green tick -> Artifacts -> Opu-APK -> download -> unzip -> install app-debug.apk.
3. IMPORTANT: GitHub signs each build with a new debug key, so uninstall the old app first, then install the new one.
4. Open the app -> Permissions tile -> allow everything. Accessibility grey? Use "Open App info" -> menu -> Allow restricted settings.
5. Brain tile -> paste Gemini key -> Save -> Test brain.

HONEST LIMITS
- Not compiled or run on a device here. If the build fails, send the red error text.
- Android does not let an app rename/re-icon its own launcher entry. "Add to home screen" makes a shortcut with your name + icon.
- 3D preview and ElevenLabs agent need internet (three.js and the agent widget load from a CDN).
- ElevenLabs agent talk is in-app only (beta).
- Always-listening: set battery to Unrestricted (Xiaomi / Oppo / Samsung kill background apps).
