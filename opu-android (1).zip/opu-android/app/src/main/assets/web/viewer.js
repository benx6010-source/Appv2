// Shared 3D viewer: used by the floating character (overlay.html) and the model preview in the app.
// Needs an importmap for "three" on the page. Config keys (all optional):
// scale, x, y, rotY, camZ, light, sway, bounce, anim, glow, glowColor
export const DEFAULT_CFG = { scale: 1, x: 0, y: 0, rotY: 0, camZ: 5.2, light: 1, sway: 1, bounce: 1, anim: 0, glow: 0, glowColor: '#ffffff' };

export async function createViewer(host, getCfg, url) {
  const THREE = await import('three');
  const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
  const cfg = () => Object.assign({}, DEFAULT_CFG, getCfg ? getCfg() : {});

  const r = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  r.setClearColor(0x000000, 0);
  r.domElement.style.cssText = 'width:100%;height:100%;display:block';
  host.appendChild(r.domElement);

  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
  const hemi = new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.4);
  const key = new THREE.DirectionalLight(0xffffff, 1.6);
  key.position.set(2, 4, 5);
  scene.add(hemi, key);

  const ctl = { state: 'idle', anims: [], apply() {}, dispose() {}, setState(s) { this.state = s; } };

  function size() {
    const w = host.clientWidth || window.innerWidth, h = host.clientHeight || window.innerHeight;
    r.setSize(w, h, false);
    cam.aspect = w / Math.max(h, 1);
    cam.updateProjectionMatrix();
  }
  size();
  const ro = new ResizeObserver(size);
  ro.observe(host);

  const gltf = await new Promise((res, rej) => new GLTFLoader().load(url, res, undefined, rej));
  const m = gltf.scene;
  const box = new THREE.Box3().setFromObject(m);
  const sz = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
  const s0 = 2.2 / Math.max(sz.y, 0.001);
  m.scale.setScalar(s0);
  m.position.sub(c.multiplyScalar(s0));
  const holder = new THREE.Group();
  holder.add(m);
  scene.add(holder);

  let mixer = null, action = null, lastAnim = -2;
  ctl.anims = (gltf.animations || []).map((a, i) => a.name || ('Animation ' + (i + 1)));
  if (gltf.animations && gltf.animations.length) mixer = new THREE.AnimationMixer(m);

  ctl.apply = function () {
    const k = cfg();
    holder.scale.setScalar(k.scale);
    cam.position.set(0, 0.35, k.camZ);
    cam.lookAt(0, 0.15, 0);
    hemi.intensity = 1.4 * k.light;
    key.intensity = 1.6 * k.light;
    r.domElement.style.filter = k.glow > 0 ? 'drop-shadow(0 0 ' + Math.round(k.glow * 28) + 'px ' + k.glowColor + ')' : 'none';
    if (mixer && lastAnim !== k.anim) {
      lastAnim = k.anim;
      if (action) action.fadeOut(0.3);
      if (k.anim >= 0 && gltf.animations[k.anim]) {
        action = mixer.clipAction(gltf.animations[k.anim]);
        action.reset().fadeIn(0.3).play();
      } else action = null;
    }
  };
  ctl.apply();

  const clock = new THREE.Clock();
  let raf = 0, dead = false;
  (function loop() {
    if (dead) return;
    raf = requestAnimationFrame(loop);
    const dt = clock.getDelta(), t = clock.elapsedTime, k = cfg();
    if (mixer) mixer.update(dt);
    const talk = ctl.state === 'talk', think = ctl.state === 'think';
    holder.rotation.y = (k.rotY * Math.PI) / 180 + Math.sin(t * 0.6) * 0.25 * k.sway;
    holder.position.x = k.x;
    holder.position.y = k.y + Math.sin(t * 1.6) * 0.03 + (talk ? Math.abs(Math.sin(t * 9)) * 0.04 * k.bounce : 0);
    holder.rotation.z = think ? Math.sin(t * 2) * 0.06 : 0;
    r.render(scene, cam);
  })();

  ctl.dispose = function () {
    dead = true;
    cancelAnimationFrame(raf);
    ro.disconnect();
    r.dispose();
    r.domElement.remove();
  };
  return ctl;
}
