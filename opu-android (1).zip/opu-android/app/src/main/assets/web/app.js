(function () {
'use strict';
/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const mock = new Proxy({}, { get: (t, k) => (k === 'getAll' ? () => '{}' : k === 'status' ? () => '{}' : () => '') });
const A = window.Android || mock;
const call = (m, ...a) => { try { return A[m](...a); } catch (e) { return ''; } };
const DEF = { app_name: 'ELIZABETH', opu_name: 'Opu', user_name: 'Axter', temperature: '0.8', chat_theme: 'system', motion: 'full', persona: '', gemini_key: '', eleven_key: '', eleven_voice: '', eleven_agent: '' };
let CFG = {}; try { CFG = JSON.parse(call('getAll') || '{}'); } catch (e) {}
let ST = {}; try { ST = JSON.parse(call('status') || '{}'); } catch (e) {}
const cget = k => (CFG[k] == null || CFG[k] === '') ? (DEF[k] || '') : CFG[k];
function cset(k, v) { CFG[k] = v; call('set', k, v); }

const IC = {
  menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  mic: '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>',
  chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  key: '<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
  box: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
  clip: '<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
  vol: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  drop: '<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2" ry="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
  radio: '<circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  down: '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>'
};
const ic = n => '<svg class="i" viewBox="0 0 24 24">' + (IC[n] || '') + '</svg>';

let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600); }

function modal(o) {
  return new Promise(res => {
    const m = $('#modal'), b = $('#mbox');
    b.innerHTML = '<h3>' + esc(o.title || '') + '</h3>' + (o.text ? '<p>' + esc(o.text) + '</p>' : '') +
      (o.input != null ? '<div class="fr" style="margin-bottom:14px"><input class="in" id="mIn" value="' + esc(o.input) + '"></div>' : '') +
      '<div class="fr"><button class="btn ghost sm" id="mNo">' + (o.cancel || 'Cancel') + '</button><button class="btn sm" id="mYes">' + (o.ok || 'OK') + '</button></div>';
    m.classList.add('on');
    const done = v => { m.classList.remove('on'); window.__modalClose = null; res(v); };
    window.__modalClose = () => done(null);
    $('#mNo').onclick = () => done(null);
    $('#mYes').onclick = () => done(o.input != null ? $('#mIn').value : true);
    if (o.input != null) setTimeout(() => { const i = $('#mIn'); i && i.focus(); }, 80);
  });
}

/* ---------- theme ---------- */
const mq = window.matchMedia('(prefers-color-scheme: light)');
function effTheme() { const t = cget('chat_theme'); return t === 'system' ? (mq.matches ? 'light' : 'dark') : t; }
function applyTheme() {
  const e = effTheme();
  document.documentElement.dataset.t = e;
  document.documentElement.dataset.m = cget('motion') === 'low' ? 'low' : 'full';
  call('setBars', e === 'light');
}
if (mq.addEventListener) mq.addEventListener('change', applyTheme);
applyTheme();

/* ---------- starfield background ---------- */
(function () {
  const c = $('#bg'), x = c.getContext('2d');
  let W = 0, H = 0, S = [], sh = [];
  function rs() { W = c.width = innerWidth; H = c.height = innerHeight; }
  rs(); addEventListener('resize', rs);
  for (let i = 0; i < 120; i++) S.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.4 + 0.3, p: Math.random() * 6.28, sp: 0.5 + Math.random() * 1.6 });
  let last = performance.now();
  (function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    x.clearRect(0, 0, W, H);
    if (document.documentElement.dataset.m === 'low') return;
    const col = document.documentElement.dataset.t === 'light' ? '0,0,0' : '255,255,255';
    const t = now / 1000;
    for (const s of S) {
      s.y -= dt * 0.004 * s.sp; if (s.y < 0) s.y = 1;
      const a = 0.15 + 0.6 * (0.5 + 0.5 * Math.sin(t * s.sp + s.p));
      x.fillStyle = 'rgba(' + col + ',' + a.toFixed(3) + ')';
      x.beginPath(); x.arc(s.x * W, s.y * H, s.r, 0, 6.2832); x.fill();
    }
    if (Math.random() < 0.006) sh.push({ x: Math.random() * W, y: Math.random() * H * 0.45, vx: 520 + Math.random() * 300, vy: 260 + Math.random() * 160, l: 1 });
    for (let i = sh.length - 1; i >= 0; i--) {
      const s = sh[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.l -= dt * 1.1;
      if (s.l <= 0) { sh.splice(i, 1); continue; }
      const g = x.createLinearGradient(s.x, s.y, s.x - s.vx * 0.12, s.y - s.vy * 0.12);
      g.addColorStop(0, 'rgba(' + col + ',' + s.l + ')'); g.addColorStop(1, 'rgba(' + col + ',0)');
      x.strokeStyle = g; x.lineWidth = 1.6; x.beginPath(); x.moveTo(s.x, s.y); x.lineTo(s.x - s.vx * 0.12, s.y - s.vy * 0.12); x.stroke();
    }
  })(last);
})();

/* ---------- opening animation ---------- */
function runSplash() {
  const el = $('#splash'), c = $('#sc'), x = c.getContext('2d');
  const name = 'ELIZABETH';
  $('#sname').innerHTML = Array.from(name).map((ch, i) => '<span style="animation-delay:' + (1.0 + i * 0.09).toFixed(2) + 's">' + ch + '</span>').join('');
  let W, H, finished = false;
  function rs() { W = c.width = innerWidth; H = c.height = innerHeight; }
  rs();
  const N = 280, st = [];
  for (let i = 0; i < N; i++) { const r = Math.random() * 30; st.push({ a: Math.random() * 6.2832, r, pr: r, w: 0.5 + Math.random() }); }
  const t0 = performance.now(); let last = t0;
  function finish() {
    if (finished) return; finished = true;
    el.classList.add('out');
    showPage('home');
    setTimeout(() => el.remove(), 900);
  }
  el.addEventListener('click', finish);
  (function loop(now) {
    if (finished) return;
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const t = (now - t0) / 1000;
    const sp = t < 1.8 ? 0.5 + 5 * (t / 1.8) * (t / 1.8) : Math.max(0.35, 5.5 - (t - 1.8) * 4);
    x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(0, 0, W, H);
    const cx = W / 2, cy = H / 2, lim = Math.hypot(cx, cy);
    for (const s of st) {
      s.pr = s.r; s.r += (s.r * 1.15 + 36) * sp * dt;
      if (s.r > lim) { s.r = Math.random() * 20; s.pr = s.r; s.a = Math.random() * 6.2832; }
      const ca = Math.cos(s.a), sa = Math.sin(s.a);
      const al = Math.min(1, s.r / 220);
      x.strokeStyle = 'rgba(255,255,255,' + al.toFixed(3) + ')'; x.lineWidth = s.w + s.r / 380;
      x.beginPath(); x.moveTo(cx + ca * s.pr, cy + sa * s.pr); x.lineTo(cx + ca * s.r, cy + sa * s.r); x.stroke();
    }
    if (t > 3.5) finish();
  })(t0);
}

/* ---------- navigation ---------- */
const pages = {};
let curPage = '', stack = [];
function mkPage(id) { const d = document.createElement('div'); d.className = 'page'; d.id = 'p-' + id; $('#app').appendChild(d); pages[id] = d; return d; }
function showPage(id, push) {
  if (id === curPage) { onShow(id); return; }
  const prev = curPage && pages[curPage];
  if (prev) { prev.classList.remove('on'); prev.classList.add('off'); setTimeout(() => prev.classList.remove('off'), 320); }
  if (push && curPage) stack.push(curPage);
  curPage = id;
  const p = pages[id]; p.classList.remove('off'); p.classList.add('on'); p.scrollTop = 0;
  onShow(id);
}
function goBack() { const p = stack.pop() || 'home'; showPage(p); }
function onShow(id) {
  refreshStatus();
  if (id === 'home') renderHome();
  else if (id === 'setup') renderSetup();
  else if (id === 'settings') renderSettings();
  else if (id === 'model') renderModel();
  else if (id === 'agent') renderAgent();
  else if (id === 'about') renderAbout();
  else if (id === 'chat') chatShow();
  if (id !== 'model') unmountViewer();
}
window.__back = function () {
  if (window.__modalClose) { window.__modalClose(); return true; }
  if (curPage === 'chat' && sideOpen && innerWidth < 900) { closeSide(); return true; }
  if (curPage && curPage !== 'home') { goBack(); return true; }
  return false;
};
function head(title, extra) {
  return '<div class="bar"><button class="ib" data-go="back">' + ic('back') + '</button><h1 class="glowtxt">' + title + '</h1>' + (extra || '') + '</div>';
}

/* ---------- status ---------- */
function refreshStatus() { try { ST = JSON.parse(call('status') || '{}'); } catch (e) {} paintStatus(); }
window.__status = function (j) { try { ST = typeof j === 'string' ? JSON.parse(j) : j; } catch (e) {} try { CFG = Object.assign(CFG, JSON.parse(call('getAll') || '{}')); } catch (e) {} paintStatus(); };
function iconSrc() { return ST.icon ? '/brand/icon.png?v=' + (CFG.icon_ver || '0') : '/assets/web/logo.png'; }
function appName() { return cget('app_name'); }
function permCount() { return [ST.mic && ST.cam, ST.overlay, ST.access, ST.battery].filter(Boolean).length; }
function paintStatus() {
  $$('[data-brand]').forEach(i => { const s = iconSrc(); if (i.getAttribute('src') !== s) i.src = s; });
  $$('[data-appname]').forEach(e => e.textContent = appName());
  const h = $('#hero');
  if (h) {
    h.classList.toggle('live', !!ST.listening);
    $('#heroSt').textContent = ST.listening ? 'Listening for “' + cget('opu_name') + '”' : 'Not listening yet';
    $('#heroBtn').innerHTML = ST.listening ? ic('stop') + ' Stop listening' : ic('mic') + ' Start listening';
    $('#pcnt') && ($('#pcnt').textContent = permCount() + '/4 ready');
    $('#kst') && ($('#kst').innerHTML = '<span class="dot ' + (ST.key ? 'ok' : '') + '"></span> ' + (ST.key ? 'Key saved' : 'Key missing'));
    $('#mst') && ($('#mst').innerHTML = '<span class="dot ' + (ST.model ? 'ok' : '') + '"></span> ' + (ST.model ? 'Model loaded' : 'Cloud mode'));
    $('#vst') && ($('#vst').innerHTML = '<span class="dot ' + (ST.voice ? 'ok' : '') + '"></span> ' + (ST.voice ? 'ElevenLabs' : 'Android voice'));
  }
  if (curPage === 'setup') paintSetup();
}
setInterval(() => { if (document.visibilityState !== 'hidden' && (curPage === 'setup' || curPage === 'home')) refreshStatus(); }, 2500);

/* ---------- home (bento) ---------- */
function tile(i, cls, go, icon, title, sub, extra) {
  return '<button class="tile ' + cls + '" style="--i:' + i + '" data-go="' + go + '"><div class="ti">' + ic(icon) + '</div><div><h3>' + title + '</h3><p>' + sub + '</p>' + (extra || '') + '</div></button>';
}
function renderHome() {
  const p = pages.home;
  p.innerHTML =
    '<div class="bar"><img data-brand class="av" src="' + iconSrc() + '"><h1 class="glowtxt" data-appname>' + esc(appName()) + '</h1>' +
    '<button class="ib" id="themeCyc" title="Theme">' + ic(effTheme() === 'light' ? 'sun' : 'moon') + '</button></div>' +
    '<div class="bento">' +
    '<div class="tile w2 h2 hero" id="hero" style="--i:0"><div class="orb"><i style="--k:0"></i><i style="--k:1"></i><i style="--k:2"></i><b></b><img data-brand src="' + iconSrc() + '"></div>' +
    '<h3 class="glowtxt" style="font-size:20px;margin:6px 0 0">Hello, ' + esc(cget('user_name')) + '</h3><p id="heroSt" style="margin:0 0 8px">…</p>' +
    '<div class="fr" style="justify-content:center"><button class="btn" id="heroBtn">…</button><button class="btn ghost" id="callBtn">' + ic('phone') + ' Call</button></div></div>' +
    tile(1, 'w2', 'chat', 'chat', 'Chat', 'Claude jaisa chat. Ask, write, code, upload images.') +
    tile(2, '', 'setup', 'shield', 'Permissions', 'Mic, overlay, screen control', '<span class="chip" id="pcnt">…</span>') +
    tile(3, '', 'settings:brain', 'cpu', 'Brain', 'Gemini key, model, persona', '<span class="chip" id="kst">…</span>') +
    tile(4, '', 'settings:voice', 'vol', 'Voice', 'ElevenLabs key + voice id', '<span class="chip" id="vst">…</span>') +
    tile(5, '', 'model', 'box', '3D body', 'Customize, replace, reset', '<span class="chip" id="mst">…</span>') +
    tile(6, '', 'settings:brand', 'image', 'Icon & name', 'Edit app icon and name') +
    tile(7, '', 'agent', 'radio', 'Voice agent', 'ElevenLabs agent (optional)') +
    tile(8, '', 'settings:theme', 'drop', 'Theme', 'System · Dark · Light · Motion') +
    tile(9, 'w2', 'about', 'star', 'ELIZABETH v3 · opu', 'Black & white glow. Fully animated.') +
    '</div>';
  paintStatus();
}

/* ---------- setup ---------- */
function renderSetup() {
  pages.setup.innerHTML = head('Permissions') + '<div class="sec" style="--i:0"><h2>' + ic('shield') + ' Setup</h2><p class="hint">Sab green ✓ ho jaye to “Opu” bolne par wo screen par aayegi.</p><div id="chkList"></div></div>' +
    '<div class="sec" style="--i:1"><h2>' + ic('info') + ' Accessibility grey hai?</h2><p class="hint">Android sideload apps ko roknta hai. App info kholo → ⋮ (3 dots) → “Allow restricted settings” → phir Accessibility me ON karo.</p><button class="btn ghost" data-act="app_settings">Open App info</button></div>';
  paintSetup();
}
function paintSetup() {
  const L = $('#chkList'); if (!L) return;
  const rows = [
    ['Microphone, camera, notifications', ST.mic && ST.cam, 'perm_media', 'Allow'],
    ['Appear over other apps', ST.overlay, 'perm_overlay', 'Allow'],
    ['Screen control (Accessibility → ' + appName() + ')', ST.access, 'perm_access', 'Open'],
    ['Keep running in background (battery: Unrestricted)', ST.battery, 'perm_battery', 'Open'],
    ['Gemini API key', ST.key, 'go:settings:brain', 'Add']
  ];
  L.innerHTML = rows.map(r => '<div class="chk"><div class="tick ' + (r[1] ? 'ok' : '') + '">' + (r[1] ? ic('check') : '') + '</div><div class="t"><b>' + r[0] + '</b></div>' + (r[1] ? '' : '<button class="btn sm" data-act="' + r[2] + '">' + r[3] + '</button>') + '</div>').join('');
}

/* ---------- settings ---------- */
function field(key, label, o) {
  o = o || {};
  const id = 'f_' + key;
  return '<div class="fl">' + label + '</div><div class="fr"><input class="in" id="' + id + '" type="' + (o.secret ? 'password' : 'text') + '" value="' + esc(CFG[key] || '') + '" placeholder="' + esc(o.ph || DEF[key] || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false">' +
    (o.secret ? '<button class="ib" data-eye="' + id + '">' + ic('eye') + '</button>' : '') +
    '<button class="btn sm" data-save="' + key + '">Save</button><button class="btn sm ghost" data-reset="' + key + '">Reset</button></div>';
}
function seg(id, opts, val) { return '<div class="seg" id="' + id + '">' + opts.map(o => '<button data-v="' + o[0] + '" class="' + (o[0] === val ? 'on' : '') + '">' + o[1] + '</button>').join('') + '</div>'; }
function renderSettings() {
  const p = pages.settings;
  p.innerHTML = head('Settings') +
    '<div class="sec" id="s-brain" style="--i:0"><h2>' + ic('cpu') + ' Brain (Gemini)</h2><p class="hint">Free key: aistudio.google.com/apikey</p>' +
    field('gemini_key', 'Gemini API key', { secret: true, ph: 'AIza…' }) +
    '<div class="fl">Model</div><div class="fr"><select class="in" id="modelSel"><option>' + esc(CFG.gemini_model || 'gemini-3.8-flash') + '</option></select><button class="btn sm ghost" id="loadModels">Load models</button><button class="btn sm" id="testBrain">Test brain</button></div>' +
    '<div class="fl">Persona (system prompt) — khali = default</div><textarea class="in" id="f_persona" placeholder="You are a warm, helpful assistant…">' + esc(CFG.persona || '') + '</textarea><div class="fr" style="margin-top:8px"><button class="btn sm" data-save="persona">Save</button><button class="btn sm ghost" data-reset="persona">Reset</button></div>' +
    '<div class="rg"><label>Creativity (temperature)</label><input type="range" id="temp" min="0" max="2" step="0.1" value="' + esc(cget('temperature')) + '"><output id="tempO">' + esc(cget('temperature')) + '</output></div><div class="fr"><button class="btn sm ghost" id="tempReset">Reset creativity</button></div>' +
    field('user_name', 'Your name') + field('opu_name', 'Her name (wake word)') + '</div>' +
    '<div class="sec" id="s-voice" style="--i:1"><h2>' + ic('vol') + ' Voice & Agent (ElevenLabs)</h2><p class="hint">Sab optional. Khali rakho to Android ki free voice chalegi.</p>' +
    field('eleven_key', 'ElevenLabs API key', { secret: true, ph: 'optional' }) + field('eleven_voice', 'Voice ID', { ph: 'optional' }) + field('eleven_agent', 'Agent ID', { ph: 'optional' }) +
    '<div class="fr" style="margin-top:12px"><button class="btn sm" id="testVoice">' + ic('vol') + ' Test voice</button></div></div>' +
    '<div class="sec" id="s-brand" style="--i:2"><h2>' + ic('image') + ' Icon & name</h2><div class="brandprev"><img data-brand src="' + iconSrc() + '"><div><b data-appname>' + esc(appName()) + '</b><p class="hint" style="margin:2px 0 0">App ke andar ka icon aur naam.</p></div></div>' +
    '<div class="fr" style="margin:12px 0"><button class="btn sm" data-act="pick_icon">Replace icon</button><button class="btn sm ghost" data-act="reset_icon">Reset icon</button><button class="btn sm ghost" data-act="pin_shortcut">Add to home screen</button></div>' +
    field('app_name', 'App name') + '<p class="hint" style="margin-top:10px">Android launcher ka asli icon/naam install ke baad badla nahi ja sakta. “Add to home screen” is naam aur icon ke saath ek naya shortcut banata hai.</p></div>' +
    '<div class="sec" id="s-theme" style="--i:3"><h2>' + ic('drop') + ' Theme</h2><div class="fl">App & chat theme</div>' +
    seg('thSeg', [['system', 'System'], ['dark', 'Dark'], ['light', 'Light']], cget('chat_theme')) +
    '<div class="fl">Motion</div>' + seg('moSeg', [['full', 'Full'], ['low', 'Reduced']], cget('motion')) +
    '<div class="fr" style="margin-top:12px"><button class="btn sm ghost" id="themeReset">Reset theme</button></div></div>' +
    '<div class="sec" style="--i:4"><h2>' + ic('trash') + ' Data</h2><div class="fr"><button class="btn sm ghost" id="expChats">' + ic('share') + ' Export chats</button><button class="btn sm danger" id="clrChats">Clear all chats</button><button class="btn sm danger" id="resetAll">Reset everything</button></div></div>';
  const sel = $('#modelSel'); sel.onchange = () => { cset('gemini_model', sel.value); toast('Model: ' + sel.value); };
  const tp = $('#temp'); tp.oninput = () => { $('#tempO').textContent = tp.value; }; tp.onchange = () => { cset('temperature', tp.value); toast('Saved'); };
  $('#tempReset').onclick = () => { cset('temperature', ''); tp.value = DEF.temperature; $('#tempO').textContent = DEF.temperature; toast('Creativity reset'); };
  $('#loadModels').onclick = () => { toast('Loading models…'); call('models'); };
  $('#testBrain').onclick = () => { toast('Testing…'); call('chat', 'test', JSON.stringify({ system: 'Reply with one word.', contents: [{ role: 'user', parts: [{ text: 'Say OK' }] }], temperature: 0.2 })); };
  $('#testVoice').onclick = () => { toast('Speaking…'); call('speak', 'Hello ' + cget('user_name') + ', main ' + cget('opu_name') + ' hoon.'); };
  $$('#thSeg button').forEach(b => b.onclick = () => { cset('chat_theme', b.dataset.v); $$('#thSeg button').forEach(x => x.classList.toggle('on', x === b)); applyTheme(); });
  $$('#moSeg button').forEach(b => b.onclick = () => { cset('motion', b.dataset.v); $$('#moSeg button').forEach(x => x.classList.toggle('on', x === b)); applyTheme(); });
  $('#themeReset').onclick = () => { cset('chat_theme', ''); cset('motion', ''); applyTheme(); renderSettings(); toast('Theme reset'); };
  $('#expChats').onclick = () => { call('share', JSON.stringify(CH, null, 1)); };
  $('#clrChats').onclick = async () => { if (await modal({ title: 'Clear all chats?', text: 'Ye wapas nahi aayenge.', ok: 'Clear' })) { CH = []; curId = null; doSave(); toast('Chats cleared'); } };
  $('#resetAll').onclick = async () => { if (await modal({ title: 'Reset everything?', text: 'Keys, names, icon, 3D model, chats — sab delete ho jayega.', ok: 'Reset' })) { try { localStorage.clear(); } catch (e) {} call('act', 'reset_all'); setTimeout(() => location.reload(), 400); } };
}
window.__models = function (list, err) {
  if (err) { toast(err); return; }
  const sel = $('#modelSel'); if (!sel) return;
  const cur = cget('gemini_model');
  sel.innerHTML = list.map(m => '<option ' + (m === cur ? 'selected' : '') + '>' + esc(m) + '</option>').join('');
  toast(list.length + ' models found');
};

/* ---------- 3D model page ---------- */
let MC = {}; try { MC = JSON.parse(cget('model_cfg') || '{}') || {}; } catch (e) {}
let V = null, saveMT;
const SL = [['scale', 'Size', 0.3, 2.5, 0.05, 1], ['x', 'Left / Right', -1.5, 1.5, 0.05, 0], ['y', 'Up / Down', -1.5, 1.5, 0.05, 0], ['rotY', 'Turn (degrees)', -180, 180, 1, 0], ['camZ', 'Camera distance', 3, 9, 0.1, 5.2], ['light', 'Light', 0, 3, 0.1, 1], ['sway', 'Sway', 0, 2, 0.1, 1], ['bounce', 'Talk bounce', 0, 2, 0.1, 1], ['glow', 'Glow', 0, 1, 0.05, 0]];
function saveMC() { clearTimeout(saveMT); saveMT = setTimeout(() => cset('model_cfg', JSON.stringify(MC)), 250); }
function renderModel() {
  pages.model.innerHTML = head('3D body') +
    '<div class="sec" style="--i:0"><div class="prev3d" id="v3d"><div class="ph"><div><img class="cl" src="/assets/web/cloud.png"><p>Abhi cloud mode. .glb / .vrm file choose karo.</p></div></div></div>' +
    '<div class="fr" style="margin-top:12px"><button class="btn sm" data-act="pick_model">' + (ST.model ? 'Replace model' : 'Choose model') + '</button><button class="btn sm ghost" data-act="remove_model">Remove / reset</button></div>' +
    '<div class="fr" style="margin-top:10px"><span class="hint" style="margin:0">Preview:</span>' + seg('stSeg', [['idle', 'Idle'], ['talk', 'Talk'], ['think', 'Think']], 'idle') + '</div></div>' +
    '<div class="sec" style="--i:1"><h2>' + ic('sliders') + ' Customize</h2><p class="hint">Yahi settings floating Opu par bhi lagti hain.</p>' +
    SL.map(s => '<div class="rg"><label>' + s[1] + '</label><input type="range" data-k="' + s[0] + '" min="' + s[2] + '" max="' + s[3] + '" step="' + s[4] + '" value="' + (MC[s[0]] != null ? MC[s[0]] : s[5]) + '"><output>' + (MC[s[0]] != null ? MC[s[0]] : s[5]) + '</output></div>').join('') +
    '<div class="fl">Animation</div><div class="fr"><select class="in" id="animSel"><option value="0">Auto (first)</option></select></div>' +
    '<div class="fl">Glow colour</div><div class="fr"><input type="color" id="glowCol" value="' + (MC.glowColor || '#ffffff') + '" style="width:60px;height:40px;border:0;background:none"></div>' +
    '<div class="fr" style="margin-top:14px"><button class="btn sm ghost" id="mcReset">Reset customization</button></div></div>';
  $$('#p-model input[type=range]').forEach(r => r.oninput = () => { MC[r.dataset.k] = parseFloat(r.value); r.nextElementSibling.textContent = r.value; V && V.apply(); saveMC(); });
  $('#glowCol').oninput = e => { MC.glowColor = e.target.value; V && V.apply(); saveMC(); };
  $('#animSel').onchange = e => { MC.anim = parseInt(e.target.value, 10); V && V.apply(); saveMC(); };
  $$('#stSeg button').forEach(b => b.onclick = () => { $$('#stSeg button').forEach(x => x.classList.toggle('on', x === b)); V && V.setState(b.dataset.v); });
  $('#mcReset').onclick = () => { MC = {}; cset('model_cfg', '{}'); renderModel(); mountViewer(); toast('Customization reset'); };
  mountViewer();
}
async function mountViewer() {
  unmountViewer();
  if (!ST.model) return;
  const host = $('#v3d'); if (!host) return;
  try {
    const mod = await import('/assets/web/viewer.js');
    const v = await mod.createViewer(host, () => MC, '/model/model.glb?v=' + (CFG.model_ver || '0'));
    if (curPage !== 'model') { v.dispose(); return; }
    V = v;
    const ph = $('.ph', host); ph && ph.remove();
    const sel = $('#animSel');
    if (sel) sel.innerHTML = '<option value="-1">None</option>' + V.anims.map((n, i) => '<option value="' + i + '">' + esc(n) + '</option>').join('');
    if (sel) sel.value = String(MC.anim != null ? MC.anim : 0);
  } catch (e) {
    const ph = $('.ph', host); if (ph) ph.innerHTML = '<div><p>3D load nahi hua. Internet check karo ya dusri .glb file try karo.</p></div>';
  }
}
function unmountViewer() { if (V) { try { V.dispose(); } catch (e) {} V = null; } }
window.__modelPicked = function (ok) { try { CFG = Object.assign(CFG, JSON.parse(call('getAll') || '{}')); } catch (e) {} refreshStatus(); toast(ok ? '3D model saved' : 'File read nahi hui'); if (curPage === 'model') renderModel(); };
window.__iconPicked = function (ok) { try { CFG = Object.assign(CFG, JSON.parse(call('getAll') || '{}')); } catch (e) {} refreshStatus(); toast(ok ? 'Icon updated' : 'Icon reset / failed'); };

/* ---------- ElevenLabs agent ---------- */
function renderAgent() {
  pages.agent.innerHTML = head('Voice agent') +
    '<div class="sec" style="--i:0"><h2>' + ic('radio') + ' ElevenLabs agent <span class="chip">beta</span></h2><p class="hint">Agent ID Settings → Voice me save karo. Private agent ho to API key bhi daalo. Internet aur mic permission chahiye.</p>' +
    '<div class="fr"><button class="btn" id="agStart">' + ic('phone') + ' Start agent</button><button class="btn ghost" data-go="settings:voice">Edit keys</button></div><div id="agentBox" style="margin-top:16px;min-height:80px"></div></div>';
  $('#agStart').onclick = () => { if (!cget('eleven_agent')) { toast('Pehle Agent ID save karo'); return; } toast('Connecting…'); call('signedUrl'); };
}
window.__signed = function (url) {
  const box = $('#agentBox'); if (!box) return;
  const mount = () => {
    const el = document.createElement('elevenlabs-convai');
    if (url) el.setAttribute('signed-url', url); else el.setAttribute('agent-id', cget('eleven_agent'));
    box.replaceChildren(el);
  };
  if (window.__elScript) { mount(); return; }
  const s = document.createElement('script'); s.src = 'https://unpkg.com/@elevenlabs/convai-widget-embed'; s.async = true;
  s.onload = () => { window.__elScript = true; mount(); };
  s.onerror = () => toast('Agent widget load nahi hua (internet?)');
  document.body.appendChild(s);
};

/* ---------- about ---------- */
function renderAbout() {
  pages.about.innerHTML = head('About') + '<div class="sec"><div class="brandprev"><img data-brand src="' + iconSrc() + '"><div><b data-appname>' + esc(appName()) + '</b><p class="hint" style="margin:2px 0 0">v3 · opu ' + esc(ST.ver || '') + '</p></div></div><p class="hint" style="margin-top:14px">Voice assistant (“' + esc(cget('opu_name')) + '” bolo), screen control, chat, 3D body — sab tumhare tablet par. Keys sirf is device me save hoti hain.</p></div>';
}

/* ---------- markdown ---------- */
function inl(s) {
  s = esc(s);
  const codes = [];
  s = s.replace(/`([^`\n]+)`/g, (m, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/__([^_\n]+)__/g, '<b>$1</b>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>').replace(/~~([^~\n]+)~~/g, '<s>$1</s>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2">$1</a>');
  return s.replace(/\u0000(\d+)\u0000/g, (m, i) => '<code>' + codes[+i] + '</code>');
}
function cblock(lang, code) {
  return '<div class="code"><div class="ch"><span>' + esc(lang || 'code') + '</span><button class="btn sm ghost" data-cc>' + ic('copy') + ' Copy</button></div><pre><code>' + esc(code) + '</code></pre></div>';
}
function md(src) {
  const L = String(src).replace(/\r/g, '').split('\n'); let o = '', i = 0, m;
  const isBlock = l => /^(```|#{1,6}\s|>|\s*[-*+]\s|\s*\d+[.)]\s|(-{3,}|\*{3,})\s*$)/.test(l);
  while (i < L.length) {
    const l = L[i];
    if ((m = l.match(/^```(\w*)/))) { const code = []; i++; while (i < L.length && !/^```/.test(L[i])) code.push(L[i++]); i++; o += cblock(m[1], code.join('\n')); continue; }
    if (/^\s*$/.test(l)) { i++; continue; }
    if ((m = l.match(/^(#{1,6})\s+(.*)/))) { o += '<h' + m[1].length + '>' + inl(m[2]) + '</h' + m[1].length + '>'; i++; continue; }
    if (/^(-{3,}|\*{3,})\s*$/.test(l)) { o += '<hr>'; i++; continue; }
    if (/^>\s?/.test(l)) { const q = []; while (i < L.length && /^>\s?/.test(L[i])) q.push(L[i++].replace(/^>\s?/, '')); o += '<blockquote>' + md(q.join('\n')) + '</blockquote>'; continue; }
    if (/^\s*[-*+]\s+/.test(l)) { const it = []; while (i < L.length && /^\s*[-*+]\s+/.test(L[i])) it.push(L[i++].replace(/^\s*[-*+]\s+/, '')); o += '<ul>' + it.map(x => '<li>' + inl(x) + '</li>').join('') + '</ul>'; continue; }
    if (/^\s*\d+[.)]\s+/.test(l)) { const it = []; while (i < L.length && /^\s*\d+[.)]\s+/.test(L[i])) it.push(L[i++].replace(/^\s*\d+[.)]\s+/, '')); o += '<ol>' + it.map(x => '<li>' + inl(x) + '</li>').join('') + '</ol>'; continue; }
    if (l.indexOf('|') >= 0 && i + 1 < L.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(L[i + 1])) {
      const cells = r => r.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(c => c.trim());
      const hd = cells(l); i += 2; const rows = [];
      while (i < L.length && L[i].indexOf('|') >= 0 && !/^\s*$/.test(L[i])) rows.push(cells(L[i++]));
      o += '<div class="tbl"><table><tr>' + hd.map(c => '<th>' + inl(c) + '</th>').join('') + '</tr>' + rows.map(r => '<tr>' + r.map(c => '<td>' + inl(c) + '</td>').join('') + '</tr>').join('') + '</table></div>'; continue;
    }
    const p = []; while (i < L.length && !/^\s*$/.test(L[i]) && !isBlock(L[i])) p.push(L[i++]);
    if (!p.length) p.push(L[i++]);
    o += '<p>' + inl(p.join('\n')).replace(/\n/g, '<br>') + '</p>';
  }
  return o;
}

/* ---------- chat ---------- */
let CH = []; try { CH = JSON.parse(localStorage.getItem('eliz_chats') || '[]'); } catch (e) {}
let curId = null, busy = false, reqId = '', stopped = false, curAm = null, sideOpen = false, pend = [], stick = true, speakingIdx = -1, recOn = false, renderQ = 0;
function doSave() {
  try { localStorage.setItem('eliz_chats', JSON.stringify(CH)); return; } catch (e) {}
  CH.forEach(c => { if (c.id !== curId) c.msgs.forEach(m => { if (m.imgs && m.imgs.length) { m.imgs = []; m.stripped = true; } }); });
  try { localStorage.setItem('eliz_chats', JSON.stringify(CH)); } catch (e) { toast('Storage full — kuch chats delete karo'); }
}
let saveT; function save() { clearTimeout(saveT); saveT = setTimeout(doSave, 300); }
const cur = () => CH.find(c => c.id === curId) || null;
function newChat() { const c = { id: 'c' + Date.now(), title: 'New chat', created: Date.now(), updated: Date.now(), msgs: [] }; CH.unshift(c); curId = c.id; return c; }
function persona() {
  return cget('persona') || ('You are ' + cget('opu_name') + ', a smart, warm and helpful AI assistant chatting with ' + cget('user_name') + '. Reply in the same language the user writes in (English, Hindi or Hinglish). Use simple clear words and short sentences unless asked for detail. Use markdown (lists, code blocks) when it helps. If you are not sure, say so honestly.');
}
function buildChat() {
  const p = pages.chat;
  p.innerHTML =
    '<div class="side" id="side"><div class="sh"><button class="btn" id="newBtn" style="flex:1">' + ic('plus') + ' New chat</button><button class="ib" id="homeBtn2">' + ic('back') + '</button></div>' +
    '<div class="fr"><input class="in" id="chatSearch" placeholder="Search chats"></div><div class="sl" id="chatList"></div></div>' +
    '<div class="scrim" id="scrim"></div>' +
    '<div class="cmain"><div class="chead"><button class="ib" id="menuBtn">' + ic('menu') + '</button><div class="tt" id="chatTitle">New chat</div><span class="chip" id="modelChip" data-go="settings:brain"></span><button class="ib" id="shareBtn">' + ic('share') + '</button><button class="ib" id="newBtn2">' + ic('plus') + '</button><button class="ib" id="homeBtn">' + ic('back') + '</button></div>' +
    '<div class="msgs" id="msgs"><div class="wrap" id="wrap"></div></div><button class="ib toBot" id="toBot">' + ic('down') + '</button>' +
    '<div class="comp"><div class="cbox"><div class="pend" id="pend"></div><textarea id="inp" rows="1" placeholder="Message ' + esc(cget('opu_name')) + '…"></textarea>' +
    '<div class="crow"><button class="ib" id="attBtn">' + ic('clip') + '</button><button class="ib mic" id="micBtn">' + ic('mic') + '</button><span class="sp"></span><button class="send" id="sendBtn">' + ic('send') + '</button></div></div></div>' +
    '<input type="file" id="fileIn" class="hide" multiple accept="image/*,.txt,.md,.json,.csv,.js,.ts,.py,.kt,.java,.html,.css,.xml,.yml,.yaml,.log,.c,.cpp,.sh"></div>';
  const inp = $('#inp');
  inp.addEventListener('input', () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight, 180) + 'px'; });
  inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && matchMedia('(pointer:fine)').matches) { e.preventDefault(); onSend(); } });
  $('#sendBtn').onclick = onSend;
  $('#attBtn').onclick = () => $('#fileIn').click();
  $('#fileIn').onchange = async e => { for (const f of Array.from(e.target.files || [])) await addFile(f); e.target.value = ''; };
  $('#micBtn').onclick = () => { if (recOn) { call('stopListen'); recOn = false; $('#micBtn').classList.remove('rec'); } else { recOn = true; $('#micBtn').classList.add('rec'); call('listen'); } };
  $('#newBtn').onclick = $('#newBtn2').onclick = () => { if (busy) return; curId = null; pend = []; renderPend(); renderChat(); closeSide(); $('#inp').focus(); };
  $('#homeBtn').onclick = $('#homeBtn2').onclick = () => showPage('home');
  $('#menuBtn').onclick = openSide; $('#scrim').onclick = closeSide;
  $('#chatSearch').oninput = renderList;
  $('#shareBtn').onclick = () => { const c = cur(); if (!c || !c.msgs.length) { toast('Chat khali hai'); return; } call('share', c.title + '\n\n' + c.msgs.map(m => (m.role === 'user' ? 'You' : cget('opu_name')) + ': ' + m.text).join('\n\n')); };
  $('#chatTitle').onclick = async () => { const c = cur(); if (!c) return; const v = await modal({ title: 'Rename chat', input: c.title, ok: 'Save' }); if (v && v.trim()) { c.title = v.trim(); save(); renderChat(); } };
  const ms = $('#msgs');
  ms.addEventListener('scroll', () => { stick = ms.scrollHeight - ms.scrollTop - ms.clientHeight < 80; $('#toBot').classList.toggle('on', !stick); });
  $('#toBot').onclick = () => { stick = true; ms.scrollTop = ms.scrollHeight; };
}
function openSide() { sideOpen = true; $('#side').classList.add('open'); $('#scrim').classList.add('on'); }
function closeSide() { sideOpen = false; $('#side').classList.remove('open'); $('#scrim').classList.remove('on'); }
function chatShow() { $('#modelChip').textContent = cget('gemini_model'); $('#inp').placeholder = 'Message ' + cget('opu_name') + '…'; renderChat(); if (!ST.key) toast('Pehle Settings me Gemini key daalo'); }
function renderList() {
  const q = ($('#chatSearch').value || '').toLowerCase(); const L = $('#chatList'); let h = '', lastG = '';
  const now = new Date(); const day = d => Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);
  const sorted = CH.slice().sort((a, b) => b.updated - a.updated); let n = 0;
  for (const c of sorted) {
    if (q && c.title.toLowerCase().indexOf(q) < 0 && !c.msgs.some(m => (m.text || '').toLowerCase().indexOf(q) >= 0)) continue;
    const d = day(new Date(c.updated)); const g = d <= 0 ? 'Today' : d === 1 ? 'Yesterday' : d < 8 ? 'Previous 7 days' : 'Older';
    if (g !== lastG) { h += '<div class="sg">' + g + '</div>'; lastG = g; }
    h += '<div class="si ' + (c.id === curId ? 'on' : '') + '" data-open="' + c.id + '" style="animation-delay:' + Math.min(n++ * 40, 400) + 'ms"><span class="n">' + esc(c.title) + '</span><span class="a"><button data-ren="' + c.id + '">' + ic('edit') + '</button><button data-del="' + c.id + '">' + ic('trash') + '</button></span></div>';
  }
  L.innerHTML = h || '<p class="hint" style="padding:10px">Koi chat nahi mili.</p>';
}
const SUGS = ['Mujhe kuch simple words me samjhao', 'Ek chhota code likh do', 'Mera message likhne me help karo', 'Aaj ka din plan karo'];
function renderChat() {
  const c = cur();
  $('#chatTitle').textContent = c ? c.title : 'New chat';
  renderList();
  const w = $('#wrap');
  if (!c || !c.msgs.length) {
    const g = 'Hello, ' + cget('user_name');
    w.innerHTML = '<div class="empty"><div class="orb"><i style="--k:0"></i><i style="--k:1"></i><b></b><img data-brand src="' + iconSrc() + '"></div><h2 class="glowtxt">' + g + '</h2><p class="hint" style="margin:0">Aaj main kaise help karun?</p><div class="sug">' + SUGS.map((s, i) => '<button style="--i:' + i + '" data-sug="' + esc(s) + '">' + esc(s) + '</button>').join('') + '</div></div>';
    return;
  }
  w.innerHTML = c.msgs.map((m, i) => msgHtml(m, i, i === c.msgs.length - 1)).join('');
  scrollEnd(true);
}
function msgHtml(m, i, last) {
  if (m.role === 'user') {
    const atts = ((m.imgs || []).map(d => '<img src="' + d + '">').join('')) + ((m.files || []).map(f => '<span class="fchip">' + ic('clip') + esc(f.name) + '</span>').join('')) + (m.stripped ? '<span class="fchip">image removed (storage)</span>' : '');
    return '<div class="msg u" data-i="' + i + '"><div class="bub">' + (atts ? '<div class="atts">' + atts + '</div>' : '') + '<div class="ut">' + esc(m.text) + '</div><div class="acts"><button data-a="edit">' + ic('edit') + '</button><button data-a="copy">' + ic('copy') + '</button><button data-a="del">' + ic('trash') + '</button></div></div></div>';
  }
  const streaming = busy && last && m === curAm;
  const body = m.text ? '<div class="md ' + (streaming ? 'cursor' : '') + '">' + md(m.text) + '</div>' : (streaming ? '<div class="dots"><i></i><i></i><i></i></div>' : '');
  const err = m.err ? '<div class="err">' + esc(m.err) + (m.err.toLowerCase().indexOf('key') >= 0 ? ' <button class="btn sm" data-go="settings:brain">Open settings</button>' : '') + '</div>' : '';
  const acts = streaming ? '' : '<div class="acts"><button data-a="copy">' + ic('copy') + '</button><button data-a="speak">' + ic(speakingIdx === i ? 'stop' : 'vol') + '</button>' + (last ? '<button data-a="regen">' + ic('refresh') + '</button>' : '') + '<button data-a="del">' + ic('trash') + '</button></div>';
  return '<div class="msg a ' + (last ? 'last' : '') + '" data-i="' + i + '"><img data-brand class="av" src="' + iconSrc() + '"><div class="bub">' + body + err + acts + '</div></div>';
}
function scrollEnd(force) { const ms = $('#msgs'); if (force || stick) ms.scrollTop = ms.scrollHeight; }
function renderPend() {
  $('#pend').innerHTML = pend.map((p, i) => '<div class="it">' + (p.img ? '<img src="' + p.img + '">' : '<span class="fchip">' + ic('clip') + esc(p.name) + '</span>') + '<button class="x" data-px="' + i + '">' + ic('x') + '</button></div>').join('');
}
function readImg(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => { const im = new Image(); im.onload = () => { const M = 1280, s = Math.min(1, M / Math.max(im.width, im.height)); const w = Math.round(im.width * s), h = Math.round(im.height * s); const cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').drawImage(im, 0, 0, w, h); res(cv.toDataURL('image/jpeg', 0.8)); }; im.onerror = rej; im.src = fr.result; };
    fr.onerror = rej; fr.readAsDataURL(file);
  });
}
async function addFile(f) {
  try {
    if (/^image\//.test(f.type)) pend.push({ img: await readImg(f), name: f.name });
    else { let t = await f.text(); if (t.length > 60000) t = t.slice(0, 60000) + '\n…(cut)'; pend.push({ name: f.name, text: t }); }
    renderPend();
  } catch (e) { toast('File add nahi hui'); }
}
function onSend() {
  if (busy) { stopped = true; call('cancel', reqId); finishStream(null); return; }
  const inp = $('#inp'); const text = inp.value.trim();
  if (!text && !pend.length) return;
  if (!ST.key) { toast('Pehle Settings me Gemini key daalo'); showPage('settings', true); return; }
  const c = cur() || newChat();
  const um = { role: 'user', text, imgs: pend.filter(p => p.img).map(p => p.img), files: pend.filter(p => !p.img).map(p => ({ name: p.name, text: p.text })), ts: Date.now() };
  c.msgs.push(um);
  if (c.msgs.length === 1) c.title = (text || (pend[0] && pend[0].name) || 'New chat').slice(0, 40);
  pend = []; renderPend(); inp.value = ''; inp.style.height = 'auto';
  startStream(c);
}
function contents(c) {
  const out = [];
  c.msgs.slice(-30).forEach(m => {
    let role, parts = [];
    if (m.role === 'assistant') { if (!m.text) return; role = 'model'; parts = [{ text: m.text }]; }
    else {
      role = 'user'; let t = m.text || ''; (m.files || []).forEach(f => { t += '\n\n[File: ' + f.name + ']\n' + f.text; });
      parts = [{ text: t || '(image)' }];
      (m.imgs || []).forEach(d => { parts.push({ inlineData: { mimeType: d.slice(5, d.indexOf(';')), data: d.slice(d.indexOf(',') + 1) } }); });
    }
    const l = out[out.length - 1];
    if (l && l.role === role) l.parts = l.parts.concat(parts); else out.push({ role, parts });
  });
  return out;
}
function startStream(c) {
  busy = true; stopped = false;
  curAm = { role: 'assistant', text: '', ts: Date.now() };
  c.msgs.push(curAm); c.updated = Date.now();
  reqId = 'r' + Date.now(); stick = true;
  renderChat(); setSendMode();
  call('chat', reqId, JSON.stringify({ system: persona(), contents: contents(c), temperature: parseFloat(cget('temperature')) || 0.8 }));
}
function setSendMode() { const b = $('#sendBtn'); b.innerHTML = busy ? ic('stop') : ic('send'); b.classList.toggle('stop', busy); }
function liveRender() {
  if (renderQ) return;
  renderQ = requestAnimationFrame(() => {
    renderQ = 0; const c = cur(); if (!c || !curAm) return;
    const els = $$('#wrap .msg.a'); const el = els[els.length - 1]; if (!el) return;
    const b = $('.bub', el); b.innerHTML = '<div class="md cursor">' + md(curAm.text) + '</div>'; scrollEnd(false);
  });
}
function finishStream(err) {
  if (!busy) return;
  busy = false; const c = cur();
  if (curAm) { if (err && !stopped) curAm.err = err; if (!curAm.text && !curAm.err) { if (c) c.msgs.pop(); } }
  curAm = null; if (c) c.updated = Date.now(); save(); setSendMode(); renderChat();
}
window.__chunk = function (id, t) { if (id === 'test') return; if (id !== reqId || !curAm || stopped) return; curAm.text += t; liveRender(); };
window.__done = function (id, err) {
  if (id === 'test') { toast(err ? '✕ ' + err : '✓ Brain working'); return; }
  if (id !== reqId) return; finishStream(err);
};
window.__voicePartial = function (t) { const i = $('#inp'); if (i) { i.value = t; i.dispatchEvent(new Event('input')); } };
window.__voice = function (t, err) {
  recOn = false; const mb = $('#micBtn'); mb && mb.classList.remove('rec');
  if (err) { toast(err === 'permission' ? 'Mic permission do, phir dobara dabao' : err === 'na' ? 'Is tablet par speech recognition nahi hai' : 'Mic busy hai (listening band karke try karo)'); return; }
  if (t) { const i = $('#inp'); i.value = t; i.dispatchEvent(new Event('input')); i.focus(); }
};
async function chatAction(a, i) {
  const c = cur(); if (!c) return; const m = c.msgs[i]; if (!m) return;
  if (a === 'copy') { call('copy', m.text); toast('Copied'); }
  else if (a === 'del') { if (busy) return; c.msgs.splice(i, 1); save(); renderChat(); }
  else if (a === 'regen') { if (busy) return; c.msgs.pop(); startStream(c); }
  else if (a === 'speak') { if (speakingIdx === i) { call('stopSpeak'); speakingIdx = -1; } else { speakingIdx = i; call('speak', m.text.replace(/```[\s\S]*?```/g, ' code ').replace(/[*_`#>]/g, '')); } renderChat(); }
  else if (a === 'edit') {
    if (busy) return;
    const el = $('#wrap .msg[data-i="' + i + '"] .bub'); if (!el) return;
    el.innerHTML = '<div class="edit"><textarea id="edTa">' + esc(m.text) + '</textarea><div class="fr" style="justify-content:flex-end;margin-top:8px"><button class="btn sm ghost" id="edNo">Cancel</button><button class="btn sm" id="edOk">Save & send</button></div></div>';
    $('#edNo').onclick = renderChat;
    $('#edOk').onclick = () => { const v = $('#edTa').value.trim(); if (!v) return; m.text = v; c.msgs.length = i + 1; if (i === 0) c.title = v.slice(0, 40); startStream(c); };
  }
}

/* ---------- global events ---------- */
document.addEventListener('click', async e => {
  const t = e.target;
  const btn = t.closest('.btn'); if (btn) { const r = btn.getBoundingClientRect(), d = Math.max(r.width, r.height), s = document.createElement('span'); s.className = 'ripple'; s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px'; btn.appendChild(s); setTimeout(() => s.remove(), 650); }
  const a = t.closest('a[href]'); if (a && /^https?:/.test(a.getAttribute('href'))) { e.preventDefault(); call('openUrl', a.getAttribute('href')); return; }
  let el;
  if ((el = t.closest('[data-go]'))) {
    const g = el.dataset.go;
    if (g === 'back') goBack();
    else if (g.indexOf('settings:') === 0) { showPage('settings', true); const sec = g.split(':')[1]; setTimeout(() => { const s = $('#s-' + sec); s && s.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 450); }
    else showPage(g, true);
    return;
  }
  if ((el = t.closest('[data-act]'))) { const k = el.dataset.act; if (k.indexOf('go:') === 0) { showPage('settings', true); } else call('act', k); setTimeout(refreshStatus, 800); return; }
  if ((el = t.closest('[data-save]'))) { const k = el.dataset.save, inp = $('#f_' + k); const v = inp.value.trim(); cset(k, v); toast('Saved ✓'); if (k === 'app_name' || k === 'opu_name' || k === 'user_name') paintStatus(); refreshStatus(); return; }
  if ((el = t.closest('[data-reset]'))) { const k = el.dataset.reset, inp = $('#f_' + k); cset(k, ''); inp.value = ''; toast('Reset ✓'); paintStatus(); refreshStatus(); return; }
  if ((el = t.closest('[data-eye]'))) { const i = $('#' + el.dataset.eye); i.type = i.type === 'password' ? 'text' : 'password'; return; }
  if ((el = t.closest('[data-cc]'))) { const code = $('code', el.closest('.code')).textContent; call('copy', code); toast('Copied'); return; }
  if ((el = t.closest('[data-sug]'))) { $('#inp').value = el.dataset.sug; onSend(); return; }
  if ((el = t.closest('[data-px]'))) { pend.splice(+el.dataset.px, 1); renderPend(); return; }
  if ((el = t.closest('[data-ren]'))) { e.stopPropagation(); const c = CH.find(x => x.id === el.dataset.ren); if (!c) return; const v = await modal({ title: 'Rename chat', input: c.title, ok: 'Save' }); if (v && v.trim()) { c.title = v.trim(); save(); renderChat(); } return; }
  if ((el = t.closest('[data-del]'))) { e.stopPropagation(); const id = el.dataset.del; if (await modal({ title: 'Delete chat?', text: 'Ye wapas nahi aayegi.', ok: 'Delete' })) { if (busy && id === curId) { stopped = true; call('cancel', reqId); busy = false; curAm = null; setSendMode(); } CH = CH.filter(x => x.id !== id); if (curId === id) curId = null; doSave(); renderChat(); } return; }
  if ((el = t.closest('[data-open]'))) { if (busy) { toast('Reply aa raha hai…'); return; } curId = el.dataset.open; renderChat(); closeSide(); return; }
  if ((el = t.closest('[data-a]'))) { const m = el.closest('.msg'); chatAction(el.dataset.a, +m.dataset.i); return; }
  if (t.closest('#themeCyc')) { const order = ['system', 'dark', 'light']; const n = order[(order.indexOf(cget('chat_theme')) + 1) % 3]; cset('chat_theme', n); applyTheme(); renderHome(); toast('Theme: ' + n); return; }
  if (t.closest('#heroBtn')) { call('act', ST.listening ? 'stop' : 'start'); setTimeout(refreshStatus, 700); return; }
  if (t.closest('#callBtn')) { call('act', 'call'); return; }
});
// spotlight that follows the finger / pointer on bento tiles
document.addEventListener('pointermove', e => { const t = e.target.closest && e.target.closest('.tile'); if (!t) return; const r = t.getBoundingClientRect(); t.style.setProperty('--mx', (e.clientX - r.left) + 'px'); t.style.setProperty('--my', (e.clientY - r.top) + 'px'); t.classList.add('hot'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('hot'), 900); }, { passive: true });
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshStatus(); });

/* ---------- boot ---------- */
['home', 'chat', 'setup', 'settings', 'model', 'agent', 'about'].forEach(mkPage);
buildChat(); renderAbout();
runSplash();
})();
