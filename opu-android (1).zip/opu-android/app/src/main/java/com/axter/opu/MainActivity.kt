package com.axter.opu

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * ELIZABETH v3. The whole app screen is a WebView (bento UI, chat, settings, 3D preview).
 * This class is the bridge: settings, permissions, files, Gemini streaming, voice.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    private var sr: SpeechRecognizer? = null
    private var appTts: TextToSpeech? = null
    private val conns = ConcurrentHashMap<String, HttpURLConnection>()
    private val cancelled = ConcurrentHashMap.newKeySet<String>()

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        var ok = false
        try {
            val dir = File(filesDir, "model").apply { mkdirs() }
            contentResolver.openInputStream(uri)!!.use { i -> File(dir, "model.glb").outputStream().use { o -> i.copyTo(o) } }
            Store.put(this, "model_ver", System.currentTimeMillis().toString())
            ok = true
        } catch (e: Exception) { toast("Couldn't read that file") }
        js("__modelPicked($ok)")
    }

    private val pickIcon = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        var ok = false
        try {
            val bmp = loadBitmap(uri, 512) ?: throw Exception("no image")
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 512, 512, true)
            val dir = File(filesDir, "brand").apply { mkdirs() }
            File(dir, "icon.png").outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Store.put(this, "icon_ver", System.currentTimeMillis().toString())
            ok = true
        } catch (e: Exception) { toast("Couldn't read that image") }
        js("__iconPicked($ok)")
    }

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = chooserCb; chooserCb = null
        cb?.onReceiveValue(if (r.resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data) else null)
    }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pushStatus() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        appTts = TextToSpeech(this) { s -> if (s == TextToSpeech.SUCCESS) appTts?.language = Locale.getDefault() }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/model/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "model").apply { mkdirs() }))
            .addPathHandler("/brand/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "brand").apply { mkdirs() }))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                openUrl(r.url.toString()); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) { chooserCb = null; false }
            }

            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread {
                    val audio = r.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray()
                    if (audio.isNotEmpty() && micOk()) r.grant(audio) else r.deny()
                }
            }
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
                    if (r != "true") { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }

    override fun onResume() { super.onResume(); if (::web.isInitialized) pushStatus() }

    override fun onDestroy() {
        runCatching { sr?.destroy() }
        runCatching { appTts?.shutdown() }
        Eleven.stop()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    /* ---------- helpers ---------- */
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun q(s: String) = JSONObject.quote(s)
    private fun js(code: String) { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.$code", null) } }
    private fun micOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == 0
    private fun camOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == 0
    private fun openUrl(u: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Can't open link") } }

    private fun statusJson(): String {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        return JSONObject()
            .put("mic", micOk()).put("cam", camOk())
            .put("overlay", Settings.canDrawOverlays(this))
            .put("access", OpuAccess.ready)
            .put("battery", pm.isIgnoringBatteryOptimizations(packageName))
            .put("listening", OpuService.running)
            .put("key", Store.geminiKey(this).isNotBlank())
            .put("model", File(filesDir, "model/model.glb").exists())
            .put("icon", File(filesDir, "brand/icon.png").exists())
            .put("voice", Eleven.configured(this))
            .put("ver", ver)
            .toString()
    }

    private fun pushStatus() { js("__status(${q(statusJson())})") }

    private fun loadBitmap(uri: Uri, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun friendly(e: Exception): String {
        val m = e.message ?: "Something went wrong"
        return when {
            m.contains("API key not valid", true) || m.contains("API_KEY_INVALID", true) -> "Gemini key galat hai. Settings me dobara daalo."
            m.contains("quota", true) || m.contains("429") -> "Gemini ki free limit poori ho gayi. Thodi der baad try karo."
            e is java.net.UnknownHostException || e is java.net.SocketTimeoutException -> "Internet nahi chal raha."
            else -> m
        }
    }

    private fun startOpu(call: Boolean) {
        if (!micOk()) {
            toast("Pehle microphone permission do")
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
            return
        }
        if (call && !Settings.canDrawOverlays(this)) { toast("Pehle “appear over other apps” allow karo"); return }
        val i = Intent(this, OpuService::class.java)
        if (call) i.action = OpuService.CALL
        try {
            ContextCompat.startForegroundService(this, i)
            if (call) moveTaskToBack(true)
        } catch (e: Exception) { toast("Start nahi hua: " + (e.message ?: "")) }
        web.postDelayed({ pushStatus() }, 700)
    }

    private fun pinShortcut() {
        val sm = getSystemService(ShortcutManager::class.java)
        if (sm == null || !sm.isRequestPinShortcutSupported) { toast("Is launcher me shortcut support nahi hai"); return }
        val f = File(filesDir, "brand/icon.png")
        val raw = if (f.exists()) BitmapFactory.decodeFile(f.path) else BitmapFactory.decodeResource(resources, R.drawable.ic_launcher)
        val bmp = Bitmap.createScaledBitmap(raw, 192, 192, true)
        val info = ShortcutInfo.Builder(this, "elz_" + System.currentTimeMillis())
            .setShortLabel(Store.appName(this).take(24))
            .setIcon(Icon.createWithBitmap(bmp))
            .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
            .build()
        sm.requestPinShortcut(info, null)
    }

    /* ---------- the bridge ---------- */
    inner class Bridge {
        @JavascriptInterface fun getAll(): String {
            val o = JSONObject()
            for (k in Store.KEYS) o.put(k, Store.get(this@MainActivity, k, Store.default(k)))
            return o.toString()
        }

        @JavascriptInterface fun set(k: String, v: String) { if (k in Store.KEYS) Store.put(this@MainActivity, k, v) }

        @JavascriptInterface fun status(): String = statusJson()

        @JavascriptInterface fun setBars(light: Boolean) {
            runOnUiThread {
                val c = if (light) Color.WHITE else Color.BLACK
                window.statusBarColor = c
                window.navigationBarColor = c
                val ic = WindowCompat.getInsetsController(window, window.decorView)
                ic.isAppearanceLightStatusBars = light
                ic.isAppearanceLightNavigationBars = light
                web.setBackgroundColor(c)
            }
        }

        @JavascriptInterface fun act(name: String) {
            runOnUiThread {
                when (name) {
                    "perm_media" -> perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
                    "perm_overlay" -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    "perm_access" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    "perm_battery" -> startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    "app_settings" -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    "start" -> startOpu(false)
                    "call" -> startOpu(true)
                    "stop" -> { stopService(Intent(this@MainActivity, OpuService::class.java)); web.postDelayed({ pushStatus() }, 500) }
                    "pick_model" -> pickModel.launch(arrayOf("*/*"))
                    "remove_model" -> { File(filesDir, "model/model.glb").delete(); Store.put(this@MainActivity, "model_cfg", "{}"); js("__modelPicked(true)") }
                    "pick_icon" -> pickIcon.launch(arrayOf("image/*"))
                    "reset_icon" -> { File(filesDir, "brand/icon.png").delete(); js("__iconPicked(true)") }
                    "pin_shortcut" -> pinShortcut()
                    "reset_all" -> {
                        stopService(Intent(this@MainActivity, OpuService::class.java))
                        Store.clearAll(this@MainActivity)
                        File(filesDir, "model/model.glb").delete()
                        File(filesDir, "brand/icon.png").delete()
                    }
                    else -> {}
                }
            }
        }

        @JavascriptInterface fun copy(text: String) {
            runOnUiThread { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", text)) }
        }

        @JavascriptInterface fun share(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Share"))
            }
        }

        @JavascriptInterface fun openUrl(u: String) { runOnUiThread { this@MainActivity.openUrl(u) } }

        /** Streams Gemini text to JS: __chunk(id, text) ... __done(id, error|null). */
        @JavascriptInterface fun chat(id: String, payload: String) {
            Thread {
                try {
                    val p = JSONObject(payload)
                    Brain.stream(
                        this@MainActivity, p.optString("system"), p.getJSONArray("contents"), p.optDouble("temperature", 0.8),
                        { cancelled.contains(id) },
                        { t -> js("__chunk(${q(id)},${q(t)})") },
                        { c -> conns[id] = c }
                    )
                    js("__done(${q(id)},null)")
                } catch (e: Exception) {
                    if (cancelled.contains(id)) js("__done(${q(id)},null)") else js("__done(${q(id)},${q(friendly(e))})")
                } finally {
                    conns.remove(id); cancelled.remove(id)
                }
            }.start()
        }

        @JavascriptInterface fun cancel(id: String) {
            cancelled.add(id)
            conns[id]?.let { c -> Thread { runCatching { c.disconnect() } }.start() }
        }

        @JavascriptInterface fun models() {
            Thread {
                try {
                    val arr = JSONArray(Brain.models(this@MainActivity))
                    js("__models(${arr}, null)")
                } catch (e: Exception) { js("__models([], ${q(friendly(e))})") }
            }.start()
        }

        @JavascriptInterface fun speak(text: String) {
            val t = text.trim().take(2500)
            if (t.isEmpty()) return
            Thread {
                if (Eleven.configured(this@MainActivity)) {
                    val f = Eleven.synth(this@MainActivity, t)
                    if (f != null) { runOnUiThread { Eleven.start(f) {} }; return@Thread }
                    runOnUiThread { toast("ElevenLabs: " + Eleven.lastError + " (Android voice use ho rahi hai)") }
                }
                runOnUiThread { appTts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "app") }
            }.start()
        }

        @JavascriptInterface fun stopSpeak() { runOnUiThread { Eleven.stop(); appTts?.stop() } }

        @JavascriptInterface fun listen() {
            runOnUiThread {
                if (!micOk()) {
                    perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
                    js("__voice('', 'permission')"); return@runOnUiThread
                }
                if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) { js("__voice('', 'na')"); return@runOnUiThread }
                runCatching { sr?.destroy() }
                val r = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
                sr = r
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                        js("__voice(${q(t)}, null)")
                    }
                    override fun onPartialResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                        js("__voicePartial(${q(t)})")
                    }
                    override fun onError(e: Int) { js("__voice('', 'err$e')") }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                try { r.startListening(i) } catch (e: Exception) { js("__voice('', 'err')") }
            }
        }

        @JavascriptInterface fun stopListen() { runOnUiThread { runCatching { sr?.stopListening() } } }

        /** ElevenLabs agent: private agents need a signed URL made with the API key. */
        @JavascriptInterface fun signedUrl() {
            Thread {
                var url = ""
                val key = Store.get(this@MainActivity, "eleven_key")
                val agent = Store.get(this@MainActivity, "eleven_agent")
                if (key.isNotBlank() && agent.isNotBlank()) {
                    try {
                        val c = URL("https://api.elevenlabs.io/v1/convai/conversation/get-signed-url?agent_id=" + java.net.URLEncoder.encode(agent, "UTF-8")).openConnection() as HttpURLConnection
                        c.setRequestProperty("xi-api-key", key)
                        c.connectTimeout = 15000; c.readTimeout = 15000
                        if (c.responseCode in 200..299) url = JSONObject(c.inputStream.bufferedReader().readText()).optString("signed_url")
                    } catch (e: Exception) { /* fall back to public agent id */ }
                }
                js("__signed(${q(url)})")
            }.start()
        }
    }
}
