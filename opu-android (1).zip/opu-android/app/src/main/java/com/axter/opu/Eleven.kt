package com.axter.opu

import android.content.Context
import android.media.MediaPlayer
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/** Optional ElevenLabs voice. If key or voice id is empty, the app uses Android's own voice. */
object Eleven {
    @Volatile var lastError: String = ""
    private var current: (() -> Unit)? = null

    fun configured(c: Context) =
        Store.get(c, "eleven_key").isNotBlank() && Store.get(c, "eleven_voice").isNotBlank()

    /** Blocking. Returns an mp3 file or null. Call from a background thread. */
    fun synth(c: Context, text: String): File? {
        return try {
            val key = Store.get(c, "eleven_key")
            val voice = URLEncoder.encode(Store.get(c, "eleven_voice"), "UTF-8")
            val con = URL("https://api.elevenlabs.io/v1/text-to-speech/$voice?output_format=mp3_44100_64").openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("xi-api-key", key)
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            if (con.responseCode in 200..299) {
                val f = File(c.cacheDir, "tts_" + System.nanoTime() + ".mp3")
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                lastError = ""
                f
            } else {
                val t = (con.errorStream ?: con.inputStream).bufferedReader().readText()
                lastError = try { JSONObject(t).getJSONObject("detail").getString("message") } catch (e: Exception) { "ElevenLabs error ${con.responseCode}" }
                null
            }
        } catch (e: Exception) {
            lastError = e.message ?: "ElevenLabs failed"
            null
        }
    }

    /** Must be called on the main thread. */
    fun start(f: File, done: () -> Unit) {
        stop()
        val mp = MediaPlayer()
        val finished = AtomicBoolean(false)
        val end: () -> Unit = {
            if (finished.compareAndSet(false, true)) {
                runCatching { mp.release() }
                f.delete()
                done()
            }
        }
        current = { runCatching { mp.stop() }; end() }
        try {
            mp.setDataSource(f.path)
            mp.setOnCompletionListener { end() }
            mp.setOnErrorListener { _, _, _ -> end(); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Exception) {
            end()
        }
    }

    fun stop() {
        val c = current
        current = null
        c?.invoke()
    }

    suspend fun play(f: File) = suspendCancellableCoroutine<Unit> { c ->
        start(f) { if (c.isActive) c.resume(Unit) }
        c.invokeOnCancellation { stop() }
    }
}
