package com.axter.opu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs all the time (shows a small notification, required by Android).
 * Hidden: waits for "Opu". Visible: stays on the call until you say go, double-tap her, or tap Stop.
 */
class OpuService : Service() {

    companion object {
        const val STOP = "com.axter.opu.STOP"
        const val CALL = "com.axter.opu.CALL"
        @Volatile var running = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private lateinit var overlay: Overlay
    private lateinit var agent: Agent
    private var inCall = false
    private var busy: Job? = null
    private var pendingAnswer: CompletableDeferred<String>? = null

    private fun wakeRegex(): Regex {
        val n = Regex.escape(Store.opuName(this).lowercase())
        return Regex("\\b(hey |hi |ok |okay )?(opu|oppu|oopu|opoo|oppo|opo|ओपू|ओपु|elizabeth|eliza|एलिज़ाबेथ|$n)\\b", RegexOption.IGNORE_CASE)
    }
    private val goAway = Regex("\\b(go away|go back|bye|goodbye|dismiss|you can go|leave now|chali jao|जाओ|चली जाओ|go)\\b", RegexOption.IGNORE_CASE)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        overlay = Overlay(this, onDismiss = { goBack() }, onTap = { if (voice.speaking) voice.shutUp() })
        voice = Voice(this) { heard(it) }
        agent = Agent(this, say = { speak(it) }, confirm = { ask(it) }, dismissCb = { main.post { goBack() } })
        voice.start()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            STOP -> { stopSelf(); return START_NOT_STICKY }
            CALL -> main.post { comeOnScreen(null) }
        }
        return START_STICKY
    }

    private fun heard(text: String) {
        main.post {
            if (inCall) {
                pendingAnswer?.let { it.complete(text); pendingAnswer = null; return@post }
                if (busy?.isActive == true) { if (Regex("\\b(stop|wait|cancel)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) { busy?.cancel(); voice.shutUp() }; return@post }
                if (goAway.containsMatchIn(text) && text.trim().split(" ").size <= 4) { goBack(true); return@post }
                converse(text)
            } else {
                val m = wakeRegex().find(text) ?: return@post
                val rest = text.substring(m.range.last + 1).trim(' ', ',', '.')
                comeOnScreen(rest.ifBlank { null })
            }
        }
    }

    private fun comeOnScreen(first: String?) {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            android.widget.Toast.makeText(this, "Allow “appear over other apps” first", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        inCall = true
        overlay.show()
        overlay.state("idle")
        if (first != null) converse(first)
        else busy = scope.launch { overlay.state("talk"); voice.say("I'm here, ${Store.userName(this@OpuService)}."); overlay.state("idle") }
    }

    private fun converse(text: String) {
        busy = scope.launch { agent.handle(text) { overlay.state(it) } }
    }

    private fun goBack(speak: Boolean = false) {
        busy?.cancel(); pendingAnswer?.cancel(); pendingAnswer = null
        voice.shutUp()
        inCall = false
        if (speak) scope.launch { overlay.state("talk"); voice.say("Okay, I'm here if you need me."); overlay.hide() } else overlay.hide()
    }

    private suspend fun speak(t: String) { overlay.state("talk"); voice.say(t); overlay.state("idle") }

    private suspend fun ask(q: String): Boolean {
        speak(q)
        val d = CompletableDeferred<String>(); pendingAnswer = d
        val a = withContext(Dispatchers.Default) { try { kotlinx.coroutines.withTimeout(15000) { d.await() } } catch (e: Exception) { "" } }
        pendingAnswer = null
        return Regex("\\b(yes|yeah|yep|sure|ok|okay|do it|go ahead|haan|ha|कर दो|हाँ)\\b", RegexOption.IGNORE_CASE).containsMatchIn(a)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("opu", "${Store.appName(this)} is listening for her name", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, OpuService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, "opu")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("${Store.appName(this)} is listening for “${Store.opuName(this)}”")
            .setContentText("Say her name to call her. Tap Stop to turn listening off.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
    }

    override fun onDestroy() {
        running = false
        voice.stop(); overlay.hide(); scope.cancel()
        super.onDestroy()
    }
}
