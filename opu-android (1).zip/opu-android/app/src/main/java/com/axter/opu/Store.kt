package com.axter.opu

import android.content.Context

/** Tiny settings store. Everything stays on this tablet. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("opu", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = "") = p(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun clearAll(c: Context) = p(c).edit().clear().apply()

    /** Keys the app screen is allowed to read and write. */
    val KEYS = setOf(
        "gemini_key", "gemini_model", "user_name", "opu_name", "app_name",
        "eleven_key", "eleven_voice", "eleven_agent",
        "persona", "temperature", "chat_theme", "motion", "model_cfg", "model_ver", "icon_ver"
    )

    fun default(k: String) = when (k) {
        "gemini_model" -> "gemini-3.8-flash"
        "user_name" -> "Axter"
        "opu_name" -> "Opu"
        "app_name" -> "ELIZABETH"
        "temperature" -> "0.8"
        "chat_theme" -> "system"
        "motion" -> "full"
        "model_cfg" -> "{}"
        else -> ""
    }

    fun geminiKey(c: Context) = get(c, "gemini_key")
    fun model(c: Context) = get(c, "gemini_model", default("gemini_model")).ifBlank { default("gemini_model") }
    fun userName(c: Context) = get(c, "user_name", "Axter").ifBlank { "Axter" }
    fun opuName(c: Context) = get(c, "opu_name", "Opu").ifBlank { "Opu" }
    fun appName(c: Context) = get(c, "app_name", "ELIZABETH").ifBlank { "ELIZABETH" }
}
