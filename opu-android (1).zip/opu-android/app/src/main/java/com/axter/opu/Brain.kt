package com.axter.opu

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini over plain HTTPS. If the saved model is retired, it asks Google for a working one. */
object Brain {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"

    private class ApiError(msg: String, val code: Int) : Exception(msg) {
        val gone get() = code == 404 || Regex("no longer available|not found|not supported|deprecated", RegexOption.IGNORE_CASE).containsMatchIn(message ?: "")
    }

    private fun request(method: String, url: String, key: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("x-goog-api-key", key)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) {
            val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { "Gemini error $code" }
            throw ApiError(msg, code)
        }
        return text
    }

    private fun listModels(key: String): List<String> {
        val j = JSONObject(request("GET", BASE + "models?pageSize=200", key, null))
        val arr = j.optJSONArray("models") ?: return emptyList()
        val out = ArrayList<Pair<String, Int>>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val name = m.getString("name").removePrefix("models/")
            val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent") || !name.contains("gemini")) continue
            if (Regex("tts|image|embed|live|audio|robotics|computer|learnlm|aqa").containsMatchIn(name)) continue
            val v = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name)?.groupValues?.get(1)?.toDouble() ?: 0.0
            var s = (v * 100).toInt()
            if (name.contains("flash")) s += 20
            if (name.contains("lite")) s -= 10
            if (name.contains("preview") || name.contains("exp")) s -= 3
            out.add(name to s)
        }
        return out.sortedByDescending { it.second }.map { it.first }
    }

    private fun generate(model: String, key: String, system: String, contents: JSONArray, json: Boolean): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.8).put("maxOutputTokens", 1200).apply {
                if (json) put("responseMimeType", "application/json")
            })
        val j = JSONObject(request("POST", BASE + "models/$model:generateContent", key, body.toString()))
        val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Gemini sent no text")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    /** Blocking. Call from a background thread. */
    fun ask(ctx: Context, system: String, contents: JSONArray, json: Boolean = true): String {
        val key = Store.geminiKey(ctx)
        if (key.isBlank()) throw Exception("Add your Gemini key in the Opu app first.")
        try {
            return generate(Store.model(ctx), key, system, contents, json)
        } catch (e: ApiError) {
            if (!e.gone) throw e
            var last: Exception = e
            for (m in listModels(key).take(6)) {
                if (m == Store.model(ctx)) continue
                try {
                    val t = generate(m, key, system, contents, json)
                    Store.put(ctx, "gemini_model", m)
                    return t
                } catch (x: ApiError) {
                    last = x
                    if (!x.gone && x.code != 429) throw x
                }
            }
            throw last
        }
    }

    /** Names of Gemini models this key can use (best first). */
    fun models(ctx: Context): List<String> {
        val key = Store.geminiKey(ctx)
        if (key.isBlank()) throw Exception("Add your Gemini key first.")
        return listModels(key)
    }

    private fun apiMessage(text: String, code: Int): String =
        try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { "Gemini error $code" }

    private fun streamOnce(
        model: String, key: String, system: String, contents: JSONArray, temp: Double,
        cancelled: () -> Boolean, onText: (String) -> Unit, onConn: (HttpURLConnection) -> Unit
    ) {
        val body = JSONObject()
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", temp).put("maxOutputTokens", 8192))
        if (system.isNotBlank())
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val c = URL(BASE + "models/$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
        onConn(c)
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("x-goog-api-key", key)
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code !in 200..299) {
            val t = (c.errorStream ?: c.inputStream).bufferedReader().readText()
            throw ApiError(apiMessage(t, code), code)
        }
        var got = false
        var blocked = ""
        c.inputStream.bufferedReader().useLines { lines ->
            for (line in lines) {
                if (cancelled()) break
                if (!line.startsWith("data:")) continue
                val js = line.removePrefix("data:").trim()
                if (js.isEmpty()) continue
                val j = try { JSONObject(js) } catch (e: Exception) { continue }
                j.optJSONObject("promptFeedback")?.optString("blockReason")?.let { if (it.isNotBlank()) blocked = it }
                val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (i in 0 until parts.length()) {
                    val t = parts.getJSONObject(i).optString("text")
                    if (t.isNotEmpty()) { got = true; onText(t) }
                }
            }
        }
        if (!got && !cancelled()) {
            throw Exception(if (blocked.isNotBlank()) "Gemini blocked this message ($blocked)." else "Gemini sent no text. Try again.")
        }
    }

    /** Blocking, streams text chunks to onText. Call from a background thread. */
    fun stream(
        ctx: Context, system: String, contents: JSONArray, temp: Double,
        cancelled: () -> Boolean, onText: (String) -> Unit, onConn: (HttpURLConnection) -> Unit
    ) {
        val key = Store.geminiKey(ctx)
        if (key.isBlank()) throw Exception("Add your Gemini API key in Settings first.")
        val first = Store.model(ctx)
        try {
            try {
                streamOnce(first, key, system, contents, temp, cancelled, onText, onConn)
            } catch (e: ApiError) {
                if (e.code != 503 && e.code != 500) throw e
                Thread.sleep(1500)
                streamOnce(first, key, system, contents, temp, cancelled, onText, onConn)
            }
        } catch (e: ApiError) {
            if (!e.gone) throw e
            var last: Exception = e
            for (m in listModels(key).take(6)) {
                if (m == first) continue
                try {
                    streamOnce(m, key, system, contents, temp, cancelled, onText, onConn)
                    Store.put(ctx, "gemini_model", m)
                    return
                } catch (x: ApiError) {
                    last = x
                    if (!x.gone && x.code != 429) throw x
                }
            }
            throw last
        }
    }

    fun userContent(text: String, jpegBase64: String? = null): JSONObject {
        val parts = JSONArray().put(JSONObject().put("text", text))
        if (jpegBase64 != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", jpegBase64)))
        return JSONObject().put("role", "user").put("parts", parts)
    }

    fun modelContent(text: String) =
        JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text)))
}
